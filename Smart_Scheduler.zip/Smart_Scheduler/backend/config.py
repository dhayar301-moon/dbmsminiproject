DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "gopalaias",
    "database": "smart_scheduler"
}